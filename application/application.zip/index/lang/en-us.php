<?php 
return [
	"首页" => "Home"
];
