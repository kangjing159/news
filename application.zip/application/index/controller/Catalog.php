<?php
namespace app\index\controller;

use think\Controller;
use app\admin\model\CatalogModel;
use think\Db;

class Catalog extends Controller
{
    public function index()
    {
    	$type[0] = Db::table('catalog_type')->where('type','=',1)->field('id,title')->select();
        $type[1] = Db::table('catalog_type')->where('type','=',2)->field('id,title')->select();
        $obj = new CatalogModel;
        $data = $obj->select();
        //dump($type);exit;
        $this->assign('data',$data);
        $this->assign('type',$type);
        return $this->fetch();
    }

    public function details()
    {
    	$db = new CatalogModel;
    	$info = $db->where('id','=',$_GET['id'])->find();
    	//$data = $db->where('type','=',$info['type'])->limit(6)->order('id desc')->field('id,title')->select();

    	//dump($data);exit;
    	//$this->assign('data',$data);
    	$this->assign('info',$info);
        return $this->fetch();
    }
    
}
