<?php
namespace app\index\controller;

use think\Controller;
use app\admin\model\ViewpointModel;

class viewpoint extends Controller
{
    public function index()
    {
    	$db = new ViewpointModel;
    	$recommend = $db->where('recommend','=',1)->order('id desc')->limit(2)->select();
    	$ranking = $db->order('num desc')->limit(8)->select();
    	$data = $db->limit(8)->select();
    	$result = [];
    	for ($i=0; $i < 3; $i++) { 
    		$result[$i]= $db->where('type','=',$i)->order('id desc')->limit(8)->select();
    	}
    	//dump($ranking);exit;
    	$this->assign('result',$result);
    	$this->assign('data',$data);
    	$this->assign('recommend',$recommend);
    	$this->assign('ranking',$ranking);
        return $this->fetch();
    }

    public function details()
    {
    	$db = new ViewpointModel;
    	$info = $db->where('id','=',$_GET['id'])->find();
    	$data = $db->where('type','=',$info['type'])->order('id desc')->limit(6)->field('id,title')->select();
    	$this->assign('data',$data);
    	$this->assign('info',$info);
        return $this->fetch();
    }
    
}
