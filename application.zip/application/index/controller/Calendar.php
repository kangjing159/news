<?php
namespace app\index\controller;

use think\Controller;

class Calendar extends Controller
{
    public function index()
    {
        return $this->fetch();
    }

    public function details()
    {
        return $this->fetch();
    }
    
}
