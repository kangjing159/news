<?php
namespace app\admin\controller;

use think\Controller;
use Session;
class Index extends Controller
{
	function __construct() {
       $ww = Session::get('USER_INFO_SESSION');
       if(!$ww){
       	$this->redirect('common/login');
       }
   }

    public function index()
    {
    	/*$ww = Session::get('USER_INFO_SESSION');
    	dump($ww);exit;*/
        return $this->fetch();
    }

    
}
